# 工作流平台部署教程（Docker + 宝塔 + PostgreSQL）

> 适用版本：当前主分支（`api.cloud.cenkor.cn`，`/www/wwwroot/api`）
> 部署方式：宝塔 Nginx 托管 HTTPS/静态 + Docker 容器跑 API + 宿主机 PostgreSQL 存数据
> 撰写日期：2026-06-06

---

## 1. 整体架构

```
┌────────────────────────────────────────────────────────────────────┐
│                         浏览器 / 回调客户端                          │
└──────────────────────────────┬─────────────────────────────────────┘
                               │ HTTPS (443)
                               ▼
┌────────────────────────────────────────────────────────────────────┐
│        宝塔 Nginx (api.cloud.cenkor.cn.conf)                       │
│        /www/server/nginx/sbin/nginx                                │
│                                                                    │
│   /         →  /www/wwwroot/api/dist  (前端 SPA 静态)               │
│   /api/     →  http://127.0.0.1:5000/api/  (反代)                  │
│   /.well-known /  SSL 验证                                       │
└──────────────────────────────┬─────────────────────────────────────┘
                               │ 127.0.0.1:5000 (host 网络,只对内)
                               ▼
┌────────────────────────────────────────────────────────────────────┐
│  Docker 容器: workflow-api  (image: workflow-api:latest)           │
│  ├─ 基础镜像: node:22-alpine                                       │
│  ├─ 工作目录: /app                                                 │
│  ├─ 入口:  node dist-api/server.js                                 │
│  ├─ 监听:   0.0.0.0:5000                                           │
│  └─ 依赖:   express, pg, cors, dotenv                              │
└──────────────────────────────┬─────────────────────────────────────┘
                               │ postgresql://api:123456@host.docker.internal:5432/api
                               │ (extra_hosts: host.docker.internal:host-gateway)
                               ▼
┌────────────────────────────────────────────────────────────────────┐
│  宿主机 PostgreSQL 16.10                                           │
│  /www/server/pgsql/bin/postgres -D /www/server/pgsql/data          │
│  监听: 0.0.0.0:5432                                                │
│  数据库: api  /  用户: api  /  密码: 123456                       │
└────────────────────────────────────────────────────────────────────┘
```

**关键设计点**：
- 容器**只监听 127.0.0.1:5000**，不对公网开放
- 容器**通过 `host.docker.internal` 访问宿主机 PG**（`extra_hosts` 自动指向 `host-gateway`）
- 前端 `dist/` 由宝塔 Nginx 直接读宿主机目录，**不走容器**（减少容器负担）
- 数据库由宝塔 PgSQL 预创建，**不放在容器里**（避免数据卷管理）

---

## 2. 前置环境

| 组件 | 版本 | 检查命令 | 备注 |
|---|---|---|---|
| Ubuntu | 24.04 LTS | `cat /etc/os-release` | 系统级 |
| 宝塔面板 | 已装 | `/www/server/panel/BT-Panel` | 提供 Nginx/PG 管理 |
| Nginx | 1.24+ | `nginx -v` | 宝塔自带 |
| PostgreSQL | 16.x | `/www/server/pgsql/bin/psql --version` | 宝塔 PgSQL 插件 |
| Docker | 20.10+ | `docker --version` | `apt install docker.io` |
| Docker Compose | v2 | `docker compose version` | 多数新版 docker 自带 |
| Node.js (宿主机) | 仅开发用 | `node -v` | **生产部署不需要**（容器内自带） |

> **宿主机 Node**：仅 `npm install pg` 装包时用到了（v14.17.6 也能装）。真正运行靠容器内 node:22-alpine。如果只是部署+运维，**宿主机可以不装 Node**。

---

## 3. 数据库准备（宝塔 PgSQL）

1. 宝塔面板 → 软件商店 → PostgreSQL 管理器 → 添加数据库
2. 填写：
   - 数据库名：`api`
   - 用户名：`api`
   - 密码：`123456`
   - 访问权限：本地服务器
3. 提交后用命令行验证：

```bash
/www/server/pgsql/bin/psql -h 127.0.0.1 -U api -d api
# 输入密码 123456 后应能进入 psql 提示符
```

> PG 16 已内置 `gen_random_uuid()`，**不需要** `CREATE EXTENSION pgcrypto`。
> 确认 PG 是 13+，否则要装 `uuid-ossp` 扩展。

---

## 4. 项目代码改造清单

本教程对应一次完整重构（从"内存态" → "PG 持久化"），改动如下：

### 4.1 新增文件

| 文件 | 作用 |
|---|---|
| `api/db.ts` | PG 连接池 + `initDb()`（执行迁移 + 种子数据） |
| `api/migrations/001_init.sql` | 7 张表 DDL，幂等 |
| `api/tsconfig.json` | 单独编译 API 用的 TS 配置 |
| `Dockerfile` | 多阶段构建 |
| `docker-compose.yml` | 容器编排 |
| `.env` | 数据库连接串等环境变量 |
| `.dockerignore` | 排除 `node_modules` / `dist` / `.git` 等 |

### 4.2 重写文件

| 文件 | 变更 |
|---|---|
| `api/store.ts` | **完全重写**：所有 `数组/Map` 操作 → PG `pool.query`，导出同名 `db` 对象 |
| `api/app.ts` | 导出 `initDb` |
| `api/server.ts` | `main()` 异步启动，先 `await initDb()` 再 `listen` |
| `api/middleware/auth.ts` | `db.sessions.get()` → `await db.getSession()` |
| `api/routes/auth.ts` | 4 处 `db.xxx` 调用加 `await` |
| `api/routes/tenants.ts` | 同上 |
| `api/routes/workflows.ts` | 3 处 |
| `api/routes/conversations.ts` | 1 处 |
| `api/routes/channels.ts` | 全部 `db.xxx` 异步化，配置读写改用 `getChannelConfig/upsertWecomConfig/upsertFeishuConfig` |
| `package.json` | 加 `pg`、`@types/pg`；改 `build` 脚本为 `build:api && build:web` |
| `/www/server/panel/vhost/nginx/api.cloud.cenkor.cn.conf` | `root` → `dist`，加 `/api/` 反代 + SPA `try_files` |
| `/www/wwwroot/api/.user.ini` | `open_basedir=/www/wwwroot/api/:/tmp/` |

---

## 5. 关键文件内容（可直接复用）

### 5.1 `api/tsconfig.json`

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "outDir": "../dist-api",
    "rootDir": ".",
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "strict": true,
    "skipLibCheck": true,
    "resolveJsonModule": true,
    "declaration": false,
    "sourceMap": false,
    "forceConsistentCasingInFileNames": true
  },
  "include": ["./**/*.ts"],
  "exclude": ["migrations/**/*"]
}
```

### 5.2 `api/migrations/001_init.sql`

```sql
-- Workflow API schema (idempotent)

CREATE TABLE IF NOT EXISTS tenants (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email       TEXT NOT NULL UNIQUE,
  password    TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS memberships (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role        TEXT NOT NULL CHECK (role IN ('platform_admin','tenant_admin','developer','operator','agent'))
);

CREATE TABLE IF NOT EXISTS sessions (
  token       TEXT PRIMARY KEY,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tenant_id   UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workflows (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  status      TEXT NOT NULL CHECK (status IN ('draft','published','archived')),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_workflows_tenant ON workflows(tenant_id);

CREATE TABLE IF NOT EXISTS conversations (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  channel       TEXT NOT NULL CHECK (channel IN ('wecom','feishu')),
  external_id   TEXT NOT NULL,
  kind          TEXT NOT NULL CHECK (kind IN ('group','direct')),
  title         TEXT NOT NULL DEFAULT '',
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, channel, external_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  conversation_id  UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  direction        TEXT NOT NULL CHECK (direction IN ('in','out')),
  sender_id        TEXT NOT NULL,
  sender_name      TEXT,
  content          TEXT NOT NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  raw              JSONB
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, created_at);

CREATE TABLE IF NOT EXISTS channel_configs (
  tenant_id   UUID PRIMARY KEY REFERENCES tenants(id) ON DELETE CASCADE,
  wecom       JSONB,
  feishu      JSONB
);
```

### 5.3 `api/db.ts`

```ts
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import pg from 'pg'

const { Pool } = pg
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

export const pool = new Pool({
  connectionString:
    process.env.DATABASE_URL ||
    'postgresql://api:123456@127.0.0.1:5432/api',
  max: 10,
})

export async function initDb(): Promise<void> {
  const sqlPath = path.join(__dirname, 'migrations', '001_init.sql')
  const sql = readFileSync(sqlPath, 'utf8')
  await pool.query(sql)

  const { rows } = await pool.query<{ count: string }>(
    'SELECT count(*)::text AS count FROM tenants',
  )
  if (Number(rows[0].count) === 0) {
    await seed()
    console.log('[db] seeded demo data')
  } else {
    console.log('[db] schema ready, existing data preserved')
  }
}

async function seed(): Promise<void> {
  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const tenantRes = await client.query<{ id: string }>(
      `INSERT INTO tenants (name) VALUES ('示例租户') RETURNING id`,
    )
    const tenantId = tenantRes.rows[0].id
    const userRes = await client.query<{ id: string }>(
      `INSERT INTO users (email, password) VALUES ('admin@example.com', '123456') RETURNING id`,
    )
    const userId = userRes.rows[0].id
    await client.query(
      `INSERT INTO memberships (tenant_id, user_id, role) VALUES ($1, $2, 'tenant_admin')`,
      [tenantId, userId],
    )
    await client.query(`INSERT INTO channel_configs (tenant_id) VALUES ($1)`, [tenantId])
    await client.query(
      `INSERT INTO workflows (tenant_id, name, status) VALUES
        ($1, '智能客服：知识库问答与转人工', 'draft'),
        ($1, '报工异常：阈值告警推送群', 'draft')`,
      [tenantId],
    )
    await client.query(
      `INSERT INTO conversations (tenant_id, channel, external_id, kind, title) VALUES
        ($1, 'wecom',  'wecom:demo-group',  'group', '设备告警群'),
        ($1, 'feishu', 'feishu:demo-group', 'group', '报工协同群')`,
      [tenantId],
    )
    await client.query('COMMIT')
  } catch (e) {
    await client.query('ROLLBACK')
    throw e
  } finally {
    client.release()
  }
}
```

### 5.4 `Dockerfile`

```dockerfile
# ---- deps ----
FROM node:22-alpine AS deps
WORKDIR /app
COPY package.json package-lock.json* ./
RUN npm install --no-audit --no-fund

# ---- api build ----
FROM deps AS api-build
COPY api ./api
COPY tsconfig.json ./
RUN npx tsc -p api/tsconfig.json

# ---- web build ----
FROM deps AS web-build
COPY . .
RUN npx vite build

# ---- runtime ----
FROM node:22-alpine AS runtime
WORKDIR /app
ENV NODE_ENV=production
ENV PORT=5000

COPY package.json package-lock.json* ./
RUN npm install --omit=dev --no-audit --no-fund

COPY --from=api-build  /app/dist-api ./dist-api
COPY --from=web-build  /app/dist      ./dist
COPY --from=api-build  /app/api/migrations ./dist-api/migrations

EXPOSE 5000
CMD ["node", "dist-api/server.js"]
```

> **路径说明**：`tsc -p api/tsconfig.json` 编译后输出 `dist-api/server.js`（在 rootDir="." 即 api/ 下，源文件 `api/server.ts` 直接落到 `dist-api/server.js`），所以容器里入口是 `dist-api/server.js`，**不是** `dist-api/api/server.js`。
> 同理，编译产物里的 `db.js` 通过 `__dirname` 找迁移，落在 `dist-api/migrations/`，所以 Dockerfile 把迁移拷到这里。

### 5.5 `docker-compose.yml`

```yaml
services:
  api:
    build: .
    image: workflow-api:latest
    container_name: workflow-api
    restart: unless-stopped
    environment:
      - NODE_ENV=production
      - PORT=5000
      - DATABASE_URL=postgresql://api:123456@host.docker.internal:5432/api
    extra_hosts:
      - "host.docker.internal:host-gateway"
    ports:
      - "127.0.0.1:5000:5000"
```

### 5.6 `.env`（宿主机 / 容器都参考）

```
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://api:123456@host.docker.internal:5432/api
```

> 宿主机上 `.env` 用 `127.0.0.1` 即可；容器内由 `host.docker.internal` 解析到宿主机 gateway。

### 5.7 `.dockerignore`

```
node_modules
dist
dist-api
.git
.trae
.zip
*.zip
.DS_Store
.vscode
.idea
```

### 5.8 宝塔 Nginx 站点：`/www/server/panel/vhost/nginx/api.cloud.cenkor.cn.conf`

```nginx
server
{
    listen 80;
    listen 443 ssl http2 ;
    server_name api.cloud.cenkor.cn;
    index index.html;
    root /www/wwwroot/api/dist;

    include /www/server/panel/vhost/nginx/well-known/api.cloud.cenkor.cn.conf;
    include /www/server/panel/vhost/nginx/extension/api.cloud.cenkor.cn/*.conf;

    ssl_certificate    /www/server/panel/vhost/cert/api.cloud.cenkor.cn/fullchain.pem;
    ssl_certificate_key    /www/server/panel/vhost/cert/api.cloud.cenkor.cn/privkey.pem;
    ssl_protocols TLSv1.1 TLSv1.2 TLSv1.3;
    ssl_ciphers EECDH+CHACHA20:EECDH+CHACHA20-draft:EECDH+AES128:RSA+AES128:EECDH+AES256:RSA+AES256:EECDH+3DES:RSA+3DES:!MD5;
    ssl_prefer_server_ciphers on;
    ssl_session_tickets on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    add_header Strict-Transport-Security "max-age=31536000";
    error_page 497  https://$host$request_uri;

    error_page 404 /404.html;

    include /www/server/panel/vhost/rewrite/api.cloud.cenkor.cn.conf;

    # API 反代
    location /api/ {
        proxy_pass http://127.0.0.1:5000/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
        proxy_connect_timeout 60s;
        client_max_body_size 50m;
    }

    # SPA fallback
    location / {
        try_files $uri $uri/ /index.html;
    }

    # 屏蔽敏感文件
    location ~* (\.user.ini|\.htaccess|\.htpasswd|\.env.*|...) { return 404; }
    location ~* /(\.git|\.svn|...|node_modules|runtime)/ { return 404; }

    access_log  /www/wwwlogs/api.cloud.cenkor.cn.log;
    error_log  /www/wwwlogs/api.cloud.cenkor.cn.error.log;
}
```

> 实际完整内容含宝塔默认的敏感文件/目录黑名单，原样保留即可。

### 5.9 `.user.ini`

```ini
open_basedir=/www/wwwroot/api/:/tmp/
```

---

## 6. 部署步骤（按顺序）

```bash
# 0. 备份（部署前必须）
mkdir -p /tmp/backup-20260606
cp /www/server/panel/vhost/nginx/api.cloud.cenkor.cn.conf /tmp/backup-20260606/
cp /www/wwwroot/api/.user.ini /tmp/backup-20260606/ 2>/dev/null

# 1. 确认宝塔 PG 已建库 (api/api/123456)
/www/server/pgsql/bin/psql -h 127.0.0.1 -U api -d api -c "SELECT 1"

# 2. 修改代码 / 写新文件（按第 4/5 章）

# 3. 装 pg 包（如本机有 node）
cd /www/wwwroot/api
npm install pg @types/pg --no-save --legacy-peer-deps || true
# 如果本机 node 版本太老，Docker build 阶段会重装，无需担心

# 4. 改 nginx 站点配置 + 测语法
/www/server/nginx/sbin/nginx -t
# ok 后
/www/server/nginx/sbin/nginx -s reload

# 5. 构建并启动容器
cd /www/wwwroot/api
docker compose build
docker compose up -d

# 6. 把前端 dist/ 从容器拷到宿主机（Nginx 要读）
docker run --rm -v /www/wwwroot/api:/out workflow-api:latest \
  sh -c "cp -r /app/dist /out/dist && chmod -R 755 /out/dist"

# 7. 验证（见第 7 章）
```

---

## 7. 验证清单

```bash
# 1. 健康检查
curl -s http://127.0.0.1:5000/api/health
# 期望: {"success":true,"message":"ok"}

curl -sk https://api.cloud.cenkor.cn/api/health
# 期望同上

# 2. 登录
curl -sk -X POST https://api.cloud.cenkor.cn/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"123456"}'
# 期望: success=true, data.token=xxx, data.user.email=admin@example.com

# 3. 拿 token 测业务接口
TOKEN="<上一步的 token>"
curl -sk https://api.cloud.cenkor.cn/api/workflows -H "Authorization: Bearer $TOKEN"
# 期望: 2 条种子 workflow

# 4. 持久化测试
curl -sk -X POST https://api.cloud.cenkor.cn/api/workflows \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"name":"部署测试 workflow"}'
# 期望: 201

docker restart workflow-api
sleep 5

# 重新登录拿新 token（重启会让旧 session 之外的 token 失效？不,session 在 PG 里,会保留）
curl -sk https://api.cloud.cenkor.cn/api/workflows -H "Authorization: Bearer $TOKEN"
# 期望: 3 条 workflow,刚才新建的还在

# 5. 前端 SPA
curl -skI https://api.cloud.cenkor.cn/
# 期望: HTTP/2 200
curl -skI https://api.cloud.cenkor.cn/assets/index-xxx.js
# 期望: 200
```

---

## 8. 常用运维命令

```bash
# 查看容器
docker ps | grep workflow
docker logs -f workflow-api
docker logs --tail 200 workflow-api

# 启停
cd /www/wwwroot/api
docker compose start
docker compose stop
docker compose restart
docker compose down       # 停并删容器（数据不动）
docker compose down -v    # 警告：会删 bind 出来的卷（这里没挂卷，安全）

# 进入容器调试
docker exec -it workflow-api sh
docker exec -it workflow-api node -e "import('./dist-api/db.js').then(m => m.pool.query('SELECT now()'))"

# 改代码后重新部署
cd /www/wwwroot/api
docker compose build
docker compose up -d
docker run --rm -v /www/wwwroot/api:/out workflow-api:latest \
  sh -c "cp -r /app/dist /out/dist && chmod -R 755 /out/dist"
/www/server/nginx/sbin/nginx -s reload  # 一般不需要,Nginx 不缓存 dist

# PG 直连
/www/server/pgsql/bin/psql -h 127.0.0.1 -U api -d api
# 常用 SQL:
#   \dt                              -- 列表
#   SELECT * FROM tenants;
#   SELECT * FROM workflows;
#   SELECT count(*) FROM messages;
#   DELETE FROM sessions;            -- 清空登录态

# 备份 PG
PGPASSWORD=123456 /www/server/pgsql/bin/pg_dump -h 127.0.0.1 -U api -d api > /tmp/api-$(date +%Y%m%d).sql
# 恢复
PGPASSWORD=123456 /www/server/pgsql/bin/psql -h 127.0.0.1 -U api -d api < /tmp/api-xxx.sql

# 备份前端（其实就是 dist/）
tar czf /tmp/dist-$(date +%Y%m%d).tar.gz /www/wwwroot/api/dist
```

---

## 9. 回退方案

如果部署后出问题，按以下顺序回退（数据不会丢，因为 PG 没动）：

```bash
# 1. 停容器
cd /www/wwwroot/api && docker compose down

# 2. 还原 nginx 配置
cp /tmp/backup-20260606/api.cloud.cenkor.cn.conf \
   /www/server/panel/vhost/nginx/api.cloud.cenkor.cn.conf
/www/server/nginx/sbin/nginx -t && /www/server/nginx/sbin/nginx -s reload

# 3. 还原 .user.ini
cp /tmp/backup-20260606/.user.ini /www/wwwroot/api/.user.ini

# 4. （可选）删除 dist/
rm -rf /www/wwwroot/api/dist

# 5. 代码回滚：git restore . 或 git checkout <旧commit>
cd /www/wwwroot/api && git checkout .
```

PG 数据**不会**因为回退而丢，下次再部署会自动连上。

---

## 10. 登录与回调地址

### 10.1 默认账号

| 字段 | 值 |
|---|---|
| 邮箱 | `admin@example.com` |
| 密码 | `123456` |
| 租户 | `示例租户` |
| 角色 | `tenant_admin` |

> 密码当前**明文存储**（按部署时选择）。生产前应改为 bcrypt，TODO。

### 10.2 平台回调地址

部署完成后，到企业微信/飞书开放平台后台填写：

| 渠道 | 回调 URL |
|---|---|
| 企业微信 | `https://api.cloud.cenkor.cn/api/channels/wecom/webhook/{tenantId}` |
| 飞书 | `https://api.cloud.cenkor.cn/api/channels/feishu/webhook/{tenantId}` |

`tenantId` 获取方式：登录后进入"渠道接入"页面会自动展示。

### 10.3 渠道配置（先配回调,才能收到消息）

进入管理台 → 渠道接入 → 填写：
- **企业微信**：CorpID / AgentID / Secret / Token / EncodingAESKey
- **飞书**：AppID / AppSecret / VerificationToken / EncryptKey

保存后即写入 PG 的 `channel_configs` 表，重启容器不丢。

---

## 11. 故障排查

| 现象 | 排查 |
|---|---|
| 容器持续 Restarting | `docker logs workflow-api`，多半是 `Cannot find module /app/dist-api/...` 或 PG 连不上 |
| `extension "pgcrypto" is not available` | 误把 `CREATE EXTENSION pgcrypto` 写进了 SQL；PG 16 用内置 `gen_random_uuid()`，删掉这行 |
| `connect ECONNREFUSED 127.0.0.1:5432` | 容器内 `127.0.0.1` 是容器自己；必须用 `host.docker.internal`（docker-compose.yml 已配 `extra_hosts`） |
| 登录 401 Invalid credentials | 容器**没灌种子**（PG 已有 tenants 但 users 为空）→ `DELETE FROM tenants CASCADE;` 重启容器 |
| `/` 返回 500 rewrite cycle | 宿主机 `/www/wwwroot/api/dist` 不存在或没有 `index.html` → 重新从容器拷出来 |
| 资源 403 | 宝塔 nginx 默认禁用 autoindex；访问具体文件 `/assets/xxx.js` 是 200 |
| 旧 n8n 端口 5678 干扰 | 已停掉旧反代；如需彻底清理：`rm -rf /www/server/panel/vhost/nginx/proxy/api.cloud.cenkor.cn/`（目录已空） |
| SSL 证书过期 | 宝塔站点 → SSL → 续签；本方案不要求容器内有证书 |

---

## 12. 端口与防火墙

容器暴露端口 `127.0.0.1:5000`，**仅本机**。外部访问一律走 443。

```bash
ss -tlnp | grep 5000   # 应该是 127.0.0.1:5000
ss -tlnp | grep 5432   # 0.0.0.0:5432 (PG,仅宝塔内网)
ss -tlnp | grep ':443' # 0.0.0.0:443 (Nginx,公网)
```

防火墙（ufw / iptables）只需要放行 80/443；5000 和 5432 不对外。

---

## 13. 升级 / 更新代码流程

```bash
cd /www/wwwroot/api

# 1. 拉新代码（或本地编辑后）
git pull

# 2. 重新构建镜像
docker compose build

# 3. 重启容器
docker compose up -d

# 4. 把新 dist 拷出来
docker run --rm -v /www/wwwroot/api:/out workflow-api:latest \
  sh -c "cp -r /app/dist /out/dist && chmod -R 755 /out/dist"

# 5. 验证
curl -sk https://api.cloud.cenkor.cn/api/health
```

如果改动了 `api/migrations/001_init.sql`（加字段/新表）：
- 把新 SQL 写成 `api/migrations/002_xxx.sql`
- 在 `api/db.ts` 里加一行 `await pool.query(readFileSync(... '002_xxx.sql'))`
- 重新 `docker compose build && docker compose up -d`

---

## 14. 目录速查

```
/www/wwwroot/api/                            # 项目根
├── api/                                     # Express 后端源码
│   ├── db.ts                                # PG 连接池
│   ├── store.ts                             # 数据访问层
│   ├── server.ts                            # 入口（main()）
│   ├── app.ts                               # Express app
│   ├── tsconfig.json                        # API 编译配置
│   ├── migrations/001_init.sql              # 建表 SQL
│   ├── middleware/auth.ts                   # 鉴权
│   └── routes/{auth,tenants,workflows,conversations,channels}.ts
├── src/                                     # React 前端源码
├── dist/                                    # 前端构建产物 (Nginx root)
├── dist-api/                                # API 编译产物 (容器内)
├── node_modules/
├── Dockerfile
├── docker-compose.yml
├── .env
├── .dockerignore
├── package.json
└── .user.ini                                # PHP open_basedir

/www/server/panel/vhost/nginx/
├── api.cloud.cenkor.cn.conf                 # 主站点配置
└── proxy/api.cloud.cenkor.cn/               # 旧 n8n 代理 (已空,可删)

/www/server/pgsql/
├── bin/psql
└── data/                                    # PG 数据目录

/tmp/backup-20260606/                        # 部署前备份
├── api.cloud.cenkor.cn.conf
└── .user.ini
```

---

## 15. 注意事项 / TODO

- [ ] **密码**：当前明文，生产前改 bcrypt
- [ ] **前端 `base`**：如果以后域名换成子路径（如 `cloud.cenkor.cn/api-app`），需在 `vite.config.ts` 设 `base: './'`
- [ ] **多实例**：当前单实例；如要多租户隔离（按文档的 `mes/cloud` 方案），每个实例起一个容器，端口分别 `5001/5002`，新建宝塔站点
- [ ] **HTTPS 强制**：当前支持 80 → 443 跳转；如要 HSTS 预加载，去掉 `add_header Strict-Transport-Security` 的注释并确认业务能撑 1 年
- [ ] **日志切割**：宝塔默认会切 `/www/wwwlogs/*.log`；容器日志用 `docker logs` 不切割，**生产建议**挂个 `json-file` log driver + logrotate
- [ ] **监控**：建议接 `docker stats` + `pg_stat_activity` 定期巡检
- [ ] **CI/CD**：可以把 `git pull && docker compose build && docker compose up -d` 包成一个 `deploy.sh`，配合 webhook 自动部署

---

## 16. 一句话总结

> **宝塔管 HTTPS+静态，Docker 跑 API，PG 落数据。三者通过 `127.0.0.1:5000` 和 `host.docker.internal:5432` 互联。**
